// JavaScript – optional for future use
console.log("Ashok Enterprise website loaded.");